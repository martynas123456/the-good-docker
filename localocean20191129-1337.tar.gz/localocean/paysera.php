<?php
if ($payment == "Apmokėjimas internetu/banku")
{
	//ijungiam payseros php
	alert('true')
}
else 
{
	//grazinam i main page (uzsakymas priimtas)
	alert('false')
}
?>